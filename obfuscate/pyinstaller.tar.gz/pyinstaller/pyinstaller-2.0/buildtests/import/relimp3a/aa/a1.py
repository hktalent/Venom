from .relimp3b import b1
from .relimp3c import c1

def getString():
  return b1.string + c1.string

