class c1:
    string = "... and this"
