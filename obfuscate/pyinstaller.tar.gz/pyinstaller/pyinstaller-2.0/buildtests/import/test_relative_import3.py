from relimp3a.aa import a1

if __name__ == '__main__':
  print a1.getString()
