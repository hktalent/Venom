
import relimp.B.C
from relimp.F import H
import relimp.relimp1

assert relimp.relimp1.name == 'relimp.relimp1'
assert relimp.B.C.name == 'relimp.B.C'
assert relimp.F.H.name == 'relimp.F.H'
