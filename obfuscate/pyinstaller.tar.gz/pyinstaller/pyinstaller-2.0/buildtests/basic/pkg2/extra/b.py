""" b.py lives in extra, but shows as pkg2.b (and pkg1.b)"""

def b_func():
    return  "b_func from pkg2.b (pkg2/extra/b.py)"
